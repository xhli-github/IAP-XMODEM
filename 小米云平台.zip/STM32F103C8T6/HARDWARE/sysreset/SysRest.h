#ifndef __SYSREST_H
#define __SYSREST_H
#include "stm32f10x.h"

void SysRest(void);

#endif



