#include "gpio.h"

/**********************************************************************
GPIO_TypeDef* GPIOx������Ϊ
			GPIOA
			GPIOB
			GPIOC
			GPIOD
			GPIOE
			GPIOF
			
u16 Pin������Ϊ
			GPIO_Pin_0 
			GPIO_Pin_1               
			GPIO_Pin_2                 
			GPIO_Pin_3                 
			GPIO_Pin_4               
			GPIO_Pin_5
			GPIO_Pin_6                 
			GPIO_Pin_7                 
			GPIO_Pin_8                 
			GPIO_Pin_9                 
			GPIO_Pin_10               
			GPIO_Pin_11             
			GPIO_Pin_12            
			GPIO_Pin_13              
			GPIO_Pin_14           
			GPIO_Pin_15              
			GPIO_Pin_All 
			
GPIOMode_TypeDef Mode������Ϊ��
			(((MODE) == GPIO_Mode_AIN) || ((MODE) == GPIO_Mode_IN_FLOATING) || \
      ((MODE) == GPIO_Mode_IPD) || ((MODE) == GPIO_Mode_IPU) || \
      ((MODE) == GPIO_Mode_Out_OD) || ((MODE) == GPIO_Mode_Out_PP) || \
      ((MODE) == GPIO_Mode_AF_OD) || ((MODE) == GPIO_Mode_AF_PP))
���磺
	 Gpio_Init(GPIOB,GPIO_Pin_5,GPIO_Mode_Out_PP);
	 Gpio_Init(GPIOE,GPIO_Pin_5,GPIO_Mode_IN_FLOATING);
***********************************************************************************/

void Gpio_Init(GPIO_TypeDef* GPIOx,u16 Pin,GPIOMode_TypeDef Mode)
{
	
	GPIO_InitTypeDef GPIO_InitStruct;
	
	if(GPIOx == GPIOA)
	{
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	}
	else if(GPIOx == GPIOB)
	{
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	}
	else if(GPIOx == GPIOC)
	{
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
	}
	else if(GPIOx == GPIOD)
	{
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD,ENABLE);
	}
	else if(GPIOx == GPIOE)
	{
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE,ENABLE);
	}
	else if(GPIOx == GPIOF)
	{
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF,ENABLE);
	}
	else if(GPIOx == GPIOG)
	{
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOG,ENABLE);
	}
	GPIO_InitStruct.GPIO_Mode = Mode;
	GPIO_InitStruct.GPIO_Pin = Pin;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOx, &GPIO_InitStruct);
	
}


void Gpio_Set_Bit(GPIO_TypeDef* GPIOx,uint16_t GPIO_Pin)
{
	GPIO_SetBits(GPIOx, GPIO_Pin);
}


void Gpio_Reset_Bit(GPIO_TypeDef* GPIOx,uint16_t GPIO_Pin)
{
	GPIO_ResetBits(GPIOx, GPIO_Pin);
}


u8 Gpio_Read_Bit(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin)
{
	return GPIO_ReadInputDataBit(GPIOx,GPIO_Pin);
}




