
/**********************************************
	USART1:PA9-TX PA10-RX
	USART2:PA2-TX PA3-RX
	USART3:PB10-TX PB11-RX
	UART4 :PC10-TX PC11-RX
	UART5 :PC12-TX PD2-RX
eg��
	Usart_Init(USART1,115200);
	Usart_Init(USART2,115200);
	Usart_Init(USART3,115200);
	Usart_Init(UART4,115200);
	Usart_Init(UART5,115200);
***********************************************/

#include "gpio.h"
#include "usart.h"
//#include "modbus.h"
#include "delay.h"
#include "flash.h"
#include "modbus_timer.h"
#include "timer.h"
#include <string.h>

//USART1���յ�������
uint8_t Receive_Buffer[45] = {0};
extern uint8_t RegBuffer[45];	
uint8_t Usart_Rev_counter = 0;
extern uint16_t Device_Address;

void Rs485_Usart(void)
{
	uint32_t BaudRate = 0;
	uint32_t Parity = 0;
	uint32_t USART_WordLength = 0;
	
	GPIO_InitTypeDef GPIO_InitStruct;
	USART_InitTypeDef USART_InitStruct;
	NVIC_InitTypeDef NVIC_InitStruct;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_9;//TX
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10;//RX
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	
	//	//RS485��������
	Gpio_Init(GPIOA,GPIO_Pin_8,GPIO_Mode_Out_PP);	
	
	
	//���������н���һ����ȡflash����
	//��ȡFLASH�еĲ������Լ���żУ��λ��Flash_Data����
	Flash_ReadDeviceData(DeviceAddressPage,Flash_Data);
	
	RegBuffer[27] = (Flash_Data[0]);
	RegBuffer[26] = (Flash_Data[0]>>8);
	RegBuffer[29] = (Flash_Data[1]);
	RegBuffer[28] = (Flash_Data[1]>>8);
	RegBuffer[31] = (Flash_Data[2]);
	RegBuffer[30] = (Flash_Data[2]>>8);
	RegBuffer[33] = (Flash_Data[3]);
	RegBuffer[32] = (Flash_Data[3]>>8);
	RegBuffer[35] = Flash_Data[4];
	RegBuffer[34] = (Flash_Data[4]>>8);
	RegBuffer[37] = Flash_Data[5];
	RegBuffer[36] = (Flash_Data[5]>>8);
	RegBuffer[39] = Flash_Data[6];
	RegBuffer[38] = (Flash_Data[6]>>8);
	
	Device_Address = Flash_Data[4];
	
	
	switch(Flash_Data[5])
	{
		case 1:		BaudRate = 1200;break;
		case 2:		BaudRate = 2400;break;
		case 4:		BaudRate = 4800;break;
		case 9:		BaudRate = 9600;break;
		case 19:	BaudRate = 19200;break;
		case 38:	BaudRate = 38400;break;
		case 57:	BaudRate = 57600;break;
		case 115:	BaudRate = 115200;break;
		default:	BaudRate = 9600;break;
	}
	switch(Flash_Data[6])
	{
		case 0:	Parity = USART_Parity_No;
						USART_WordLength = USART_WordLength_8b;
						break;
		case 1:	Parity = USART_Parity_Odd;
						USART_WordLength = USART_WordLength_9b;
						break;
		case 2:	Parity = USART_Parity_Even;
						USART_WordLength = USART_WordLength_9b;
						break;
		default:Parity = USART_Parity_No;
						USART_WordLength = USART_WordLength_8b;
						break;
	}
		USART_InitStruct.USART_BaudRate = BaudRate;
		USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
		USART_InitStruct.USART_Mode = USART_Mode_Rx|USART_Mode_Tx;
		USART_InitStruct.USART_Parity = Parity;
		USART_InitStruct.USART_StopBits = USART_StopBits_1;
		USART_InitStruct.USART_WordLength = USART_WordLength;
		USART_Init(USART1, &USART_InitStruct);
			
		NVIC_InitStruct.NVIC_IRQChannel = USART1_IRQn;
		NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
		NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;
		NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;
		NVIC_Init(&NVIC_InitStruct);
	
	//ʹ��RS485����
		GPIO_ResetBits(GPIOA, GPIO_Pin_8);
//	//RS485ʹ��
//#ifdef Rs485_Auto
//	Rs485_EN();
//#else
//	Rs485_Rx_EN();
//#endif
	//Ϊ�˷�ֹ��ʱ����ʼ������usart��ʼ��ǰ���¸����Զ���װ�ؼĴ���
	//��ֵ�����Խ���ʱ����ʼ�����ڴ��ڳ�ʼ���С�
	Timer_Init();
	//����Modbusÿһ֡��ʱ����
	Modbus_Set_Timeout(&BaudRate);
	
	USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);
	
	USART_Cmd(USART1,ENABLE);
}




void Usart_Init(USART_TypeDef* USARTx,uint32_t USART_BaudRate)
{
//	uint32_t BaudRate = 0;
	USART_InitTypeDef USART_InitStruct;
	NVIC_InitTypeDef NVIC_InitStruct;
	GPIO_InitTypeDef GPIO_InitStruct;

	if(USARTx == USART1)
	{
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA, ENABLE);
		
		GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
		GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_InitStruct.GPIO_Pin = GPIO_Pin_9;//TX
		GPIO_Init(GPIOA,&GPIO_InitStruct);
		
		GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
		GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10;//RX
		GPIO_Init(GPIOA,&GPIO_InitStruct);
	}
	else if(USARTx == USART2)
	{
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
		
		GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
		GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_InitStruct.GPIO_Pin = GPIO_Pin_2;//TX
		GPIO_Init(GPIOA,&GPIO_InitStruct);
		
		GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
		GPIO_InitStruct.GPIO_Pin = GPIO_Pin_3;//RX
		GPIO_Init(GPIOA,&GPIO_InitStruct);
	}
	else if(USARTx == USART3)
	{
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3,ENABLE);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
		
		GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
		GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10;//TX
		GPIO_Init(GPIOB,&GPIO_InitStruct);
		
		GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
		GPIO_InitStruct.GPIO_Pin = GPIO_Pin_11;//RX
		GPIO_Init(GPIOB,&GPIO_InitStruct);
	}

#ifdef STM32F10X_HD
	else if(USARTx == UART4)
	{
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4,ENABLE);	
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
		
		GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
		GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10;//TX
		GPIO_Init(GPIOC,&GPIO_InitStruct);
		
		GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
		GPIO_InitStruct.GPIO_Pin = GPIO_Pin_11;//RX
		GPIO_Init(GPIOC,&GPIO_InitStruct);
	}
	else if(USARTx == UART5)
	{
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5,ENABLE);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);		
		
		GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
		GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_InitStruct.GPIO_Pin = GPIO_Pin_12;//TX
		GPIO_Init(GPIOC,&GPIO_InitStruct);
		
		GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
		GPIO_InitStruct.GPIO_Pin = GPIO_Pin_2;//RX
		GPIO_Init(GPIOD,&GPIO_InitStruct);
	}
#endif
//	
//		//���������н���һ����ȡflash����
//	//��ȡFLASH�еĲ������Լ���żУ��λ��Flash_Data����
//	Flash_ReadDeviceData(DeviceAddressPage,Flash_Data);
//	
////	RegBuffer[27] = (uint8_t)(Flash_Data[0]);
////	RegBuffer[26] = (Flash_Data[0]>>8);
////	RegBuffer[29] = (Flash_Data[1]);
////	RegBuffer[28] = (Flash_Data[1]>>8);
////	RegBuffer[31] = (Flash_Data[2]);
////	RegBuffer[30] = (Flash_Data[2]>>8);
////	RegBuffer[33] = (Flash_Data[3]);
////	RegBuffer[32] = (Flash_Data[3]>>8);

//	RegBuffer[35] = (uint8_t)(Flash_Data[4] & 0x00FF);
//	RegBuffer[34] = (uint8_t)(((Flash_Data[4] & 0xFF00)>>8));
//	RegBuffer[37] = (uint8_t)(Flash_Data[5] & 0x00FF);
//	RegBuffer[36] = (uint8_t)(((Flash_Data[5] & 0Xff00)>>8));
//	RegBuffer[39] = (uint8_t)(Flash_Data[6] & 0x00ff);
//	RegBuffer[38] = (uint8_t)(((Flash_Data[6] & 0xFF00)>>8));
//	switch(Flash_Data[5])
//	{
//		case 1:		BaudRate = 1200;break;
//		case 2:		BaudRate = 2400;break;
//		case 4:		BaudRate = 4800;break;
//		case 9:		BaudRate = 9600;break;
//		case 19:	BaudRate = 19200;break;
//		case 38:	BaudRate = 38400;break;
//		case 57:	BaudRate = 57600;break;
//		case 115:	BaudRate = 115200;break;
//		default:	BaudRate = 9600;break;
//	}
//	switch(Flash_Data[6])
//	{
//		case 0:	Parity = USART_Parity_No;
//						USART_WordLength = USART_WordLength_8b;
//						break;
//		case 1:	Parity = USART_Parity_Odd;
//						USART_WordLength = USART_WordLength_9b;
//						break;
//		case 2:	Parity = USART_Parity_Even;
//						USART_WordLength = USART_WordLength_9b;
//						break;
//		default:Parity = USART_Parity_No;
//						USART_WordLength = USART_WordLength_8b;
//						break;
//	}
	
		USART_InitStruct.USART_BaudRate = USART_BaudRate;
		USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
		USART_InitStruct.USART_Mode = USART_Mode_Rx|USART_Mode_Tx;
		USART_InitStruct.USART_Parity = USART_Parity_No;
		USART_InitStruct.USART_StopBits = USART_StopBits_1;
		USART_InitStruct.USART_WordLength = USART_WordLength_8b;
		USART_Init(USARTx, &USART_InitStruct);

	
	if(USARTx == USART1)
	{
//		USART_InitStruct.USART_BaudRate = BaudRate;
//		USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
//		USART_InitStruct.USART_Mode = USART_Mode_Rx|USART_Mode_Tx;
//		USART_InitStruct.USART_Parity = USART_Parity_No;
//		USART_InitStruct.USART_StopBits = USART_StopBits_1;
//		USART_InitStruct.USART_WordLength = USART_WordLength_8b;
//		USART_Init(USARTx, &USART_InitStruct);
			
		NVIC_InitStruct.NVIC_IRQChannel = USART1_IRQn;
		NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
		NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;
		NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;
		NVIC_Init(&NVIC_InitStruct);
	}
	else if(USARTx == USART2)
	{
		NVIC_InitStruct.NVIC_IRQChannel = USART2_IRQn;
		NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
		NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 2;
		NVIC_InitStruct.NVIC_IRQChannelSubPriority = 2;
		NVIC_Init(&NVIC_InitStruct);
	}
	else if(USARTx == USART3)
	{
		NVIC_InitStruct.NVIC_IRQChannel = USART3_IRQn;
		NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
		NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 2;
		NVIC_InitStruct.NVIC_IRQChannelSubPriority = 3;
		NVIC_Init(&NVIC_InitStruct);
	}

#ifdef STM32F10X_HD
	else if(USARTx == UART4)
	{
		NVIC_InitStruct.NVIC_IRQChannel = UART4_IRQn;	
		NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
		NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;
		NVIC_InitStruct.NVIC_IRQChannelSubPriority = 0;
		NVIC_Init(&NVIC_InitStruct);
	}
	else if(USARTx == UART5)
	{
		NVIC_InitStruct.NVIC_IRQChannel = UART5_IRQn;
		NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
		NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;
		NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;
		NVIC_Init(&NVIC_InitStruct);
	}
#endif

	USART_ITConfig(USARTx,USART_IT_RXNE,ENABLE);

	USART_Cmd(USARTx, ENABLE);
}

void Usart_Send_Byte(USART_TypeDef* USARTx, uint16_t Data)
{
	USART_SendData(USARTx,Data);
}

//void Usart_Send(USART_TypeDef* USARTx, uint8_t *Data ,uint32_t len)
//{
//	uint32_t i = 0;
//	for(i=0;i<len;i++)
//	{
//		while(!(USART_GetFlagStatus(USARTx,USART_FLAG_TXE)));
//		USART_SendData(USARTx,Data[i]);
//	}
//}

void Usart_Send(uint8_t *Data,uint8_t Len)
{
	uint8_t Times = 0;
	USART_ClearFlag(USART1,USART_FLAG_TC);
	GPIO_SetBits(GPIOA, GPIO_Pin_8);
	for(Times=0;Times<Len;Times++)
	{
		USART_SendData(USART1,Data[Times]);
		while(!(USART_GetFlagStatus(USART1,USART_FLAG_TC)));
		USART_ClearFlag(USART1,USART_FLAG_TC);
	}
	GPIO_ResetBits(GPIOA, GPIO_Pin_8);
}

void USART1_IRQHandler(void)
{
	
	if(USART_GetITStatus(USART1,USART_IT_RXNE))
	{
		USART_ClearITPendingBit(USART1,USART_IT_RXNE);	
				
		Receive_Transmit_Buffer[Usart_Rev_counter++] = USART_ReceiveData(USART1);
		
		//��ռ���������ʼ��ʱ��
		Modbus_Timer_Start();
	}
}



#if 0
void USART1_IRQHandler(void)
{
	
	if(USART_GetITStatus(USART1,USART_IT_RXNE))
	{
		static uint8_t receive_counter = 0;
		uint16_t TxLen = 0;

		
		USART_ClearITPendingBit(USART1,USART_IT_RXNE);

		Receive_Buffer[receive_counter++] = USART_ReceiveData(USART1);
	
		if(receive_counter >= 8)
		{
			receive_counter = 0;
			
			Modbus_Rtu(Receive_Buffer,&TxLen);
			
			GPIO_SetBits(GPIOA, GPIO_Pin_8);
			delay_us(10);
			Usart_Send(USART1,Receive_Buffer,TxLen);
			delay_ms(100);
			GPIO_ResetBits(GPIOA, GPIO_Pin_8);
			
		}

	}
}

#endif

#if 0
void USART2_IRQHandler(void)
{
	static uint8_t Counter = 0;
	uint16_t PM2_5_Data = 0;
	static uint16_t gp2y10_value[7] = {0};
	
	if(USART_GetITStatus(USART2,USART_IT_RXNE))
	{
		USART_ClearITPendingBit(USART2,USART_IT_RXNE);

		gp2y10_value[Counter++] = USART_ReceiveData(USART2);
		
		if(gp2y10_value[0] == 0XAA)
		{
			if((gp2y10_value[6] == 0XFF)&&(Counter == 7))
			{
				Counter = 0;
				if(gp2y10_value[5] == (gp2y10_value[1] + gp2y10_value[2] + gp2y10_value[3] + gp2y10_value[4]))
				{
				  PM2_5_Data = (uint16_t)((float)((gp2y10_value[1] * 256) + gp2y10_value[2]) / 1024.0 * 5.0 * 800.0);
					if(PM2_5_Data > 3000)
					{
						PM2_5_Data = 3000;
					}
				  RegBuffer[11] = (uint8_t)(PM2_5_Data);
					RegBuffer[10] = (uint8_t)((PM2_5_Data & 0xFF00) >> 8);
				}
			}
			else if((gp2y10_value[6] != 0XFF)&&(Counter == 7))
			{
			 Counter = 0;
			}
		}
		else
		{
		 Counter = 0;
		}
	}

}

#endif

void USART3_IRQHandler(void)
{
 static uint8_t USART3_RECV_Buffer[10] = {0};
 static uint8_t USART3_RECV_Counter = 0;
// static uint16_t CH2O_Value = 0;
	if(USART_GetITStatus(USART3,USART_IT_RXNE))
	{
  USART_ClearITPendingBit(USART3,USART_IT_RXNE);
		USART3_RECV_Buffer[USART3_RECV_Counter++] = USART_ReceiveData(USART3);
  if((USART3_RECV_Buffer[0] == 0xFF) && (USART3_RECV_Buffer[1] == 0x17)
   &&(USART3_RECV_Buffer[2] == 0x04)&& (USART3_RECV_Counter == 9))
  {
   USART3_RECV_Counter = 0;
//   CH2O_Value = (USART3_RECV_Buffer[4] << 8) + USART3_RECV_Buffer[5];
   RegBuffer[20] = USART3_RECV_Buffer[4];
   RegBuffer[21] = USART3_RECV_Buffer[5];
   memset(USART3_RECV_Buffer,0,10);

  }
  else if((USART3_RECV_Buffer[0] != 0xFF) || 
   ((USART3_RECV_Buffer[0] == 0xFF) && (USART3_RECV_Buffer[1] != 0x17) &&(USART3_RECV_Counter == 2)) ||
   ((USART3_RECV_Buffer[0] == 0xFF) && (USART3_RECV_Buffer[1] == 0x17)&&
   (USART3_RECV_Buffer[2] != 0x04)&&(USART3_RECV_Counter == 3)))
  {
   USART3_RECV_Counter = 0;
   memset(USART3_RECV_Buffer,0,10);
  }
   
	}
}

void UART4_IRQHandler(void)
{
	if(USART_GetITStatus(UART4,USART_IT_RXNE))
	{
		uint16_t RecData = USART_ReceiveData(UART4);
		USART_SendData(UART4,RecData);
	}
}

void UART5_IRQHandler(void)
{
	if(USART_GetITStatus(UART5,USART_IT_RXNE))
	{
		uint16_t RecData = USART_ReceiveData(UART5);
		USART_SendData(UART5,RecData);
	}
}



