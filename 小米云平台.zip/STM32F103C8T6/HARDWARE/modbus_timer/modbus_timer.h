#ifndef __MODBUS_H
#define __MODBUS_H
#include "stm32f10x.h"

#define RegBuffer_Len 									45
#define Coil_status_Len 							  4
#define Receive_Transmit_Buffer_Len 		45
#define DI_Status_Len										4

extern uint8_t DI_Status[DI_Status_Len];
extern uint8_t Coil_Status[Coil_status_Len];
extern uint8_t Receive_Transmit_Buffer[Receive_Transmit_Buffer_Len];
extern uint8_t RegBuffer[RegBuffer_Len];


#define ERR_CODE_CMD												0x01	/* ��֧�ֵĹ����� */
#define ERR_CODE_REG_ADDR										0x02	/* �Ĵ�����ַ���� */
#define ERR_CODE_VALUE											0x03	/* ����ֵ����� */
#define ERR_CODE_WRITE											0x04	/* д��ʧ�� */
#define ERR_CODE_CRC										   	0x05	/* CRCУ��ʧ�� */
#define ERR_CODE_LEN										   	0x06	/* ���յ������ݳ��ȴ��� */


uint16_t Modbus_Rtu(uint8_t *Receive_Transmit_Buffer,uint8_t *RegBuffer,uint8_t *__DI_Status,
										uint8_t *__Coil_Status,uint8_t Device_address);
void Packing_ErrCode(uint8_t *__Receive_Transmit_Buffer,uint8_t ErrCode,uint16_t *Modbus_Send_Len);		
void Set_Relay(void);
void FunCode01(uint8_t *Receive_Transmit_Buffer,uint8_t *__Coil_Status,uint16_t *Modbus_Send_Len);
void FunCode02(uint8_t *Receive_Transmit_Buffer,uint8_t *__DI_Status,uint16_t *Modbus_Send_Len);
void FunCode03_04(uint8_t *Receive_Transmit_Buffer,uint8_t *RegBuffer,uint16_t *Modbus_Send_Len);
void FunCode05(uint8_t *Receive_Transmit_Buffer,uint8_t *__Coil_Status,uint16_t *Modbus_Send_Len);
void FunCode06(uint8_t *Receive_Transmit_Buffer,uint8_t *RegBuffer,uint16_t *Modbus_Send_Len);
#endif


