#ifndef __PWMDAC_H
#define __PWMDAC_H

#include "stm32f10x.h"


void Pwmdac_Init(void);
void Set_Duty(uint16_t Duty);
#endif


