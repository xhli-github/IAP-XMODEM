#ifndef __HDC_1080_H
#define __HDC_1080_H
#include "stm32f10x.h"

#define HDC1080_ADDRESS					0x80

#define HDC1080_SDA_DATA(a)	if (a)	\
							GPIO_SetBits(GPIOB,GPIO_Pin_9);\
							else		\
							GPIO_ResetBits(GPIOB,GPIO_Pin_9)
							
#define HDC1080_SCL_OUT(a)	if (a)	\
							GPIO_SetBits(GPIOB,GPIO_Pin_8);\
							else		\
							GPIO_ResetBits(GPIOB,GPIO_Pin_8)														
							
#define HDC1080_SDA_IO_IN       GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9)

void Hdc1080_Init(void);
void Hdc1080_Config(void);
int Get_HDC1080_Temperature(void);
uint16_t Get_HDC1080_Humidity(void);
#endif



