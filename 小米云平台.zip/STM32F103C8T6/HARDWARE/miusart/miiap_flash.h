#ifndef __MIIAPFLASH_H
#define __MIIAPFLASH_H
#include "stm32f10x.h"

#define Flash_Data_Address    0x0800FC00
#define Flash_Data_Page       63
#define FLASH_Data_Len        10


extern uint16_t FLASH_Data_Buffer[FLASH_Data_Len];


void Flash_ReadDeviceData(uint32_t Page,uint16_t *Flash_Data_Temp,uint16_t Data_Len);
void Flash_WriteDeviceHalfWord(uint32_t Page,uint16_t *Data,uint16_t Data_Len);
void Flash_WriteDeviceByte(uint32_t Page,uint8_t *Data,uint16_t Data_Len);
//void IAP_WriteToFlash(uint32_t IAP_Page,uint8_t *IAP_Buffer,uint16_t IAP_Buffer_Len);

#endif


