#include "timer.h"
#include "gpio.h"
#include "usart.h"
#include "modbus_timer.h"
#include "delay.h"

//#include "modbus.h"
//#include "main.h"
//#include "mt6501.h"
extern uint8_t Usart_Rev_counter;
extern uint16_t Device_Address;
OS_FLAG_t OS_Flag = {0};
//us����ʱ����ʼ��
void Timer_Init(void)
{
	NVIC_InitTypeDef NVIC_InitStruct;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);
	
	TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStruct.TIM_Period = 0;
	TIM_TimeBaseInitStruct.TIM_Prescaler = 47;
	TIM_TimeBaseInitStruct.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitStruct);
	
	NVIC_InitStruct.NVIC_IRQChannel = TIM3_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 3;
	NVIC_Init(&NVIC_InitStruct);
	
	TIM_ITConfig(TIM3,TIM_IT_Update,DISABLE);
	
	TIM_Cmd(TIM3,DISABLE);
}

void Modbus_Timer_Start(void)
{
	TIM_SetCounter(TIM3,0);
	TIM_ClearITPendingBit(TIM3,TIM_IT_Update);
	TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);
	TIM_Cmd(TIM3,ENABLE);
}

void Modbus_Timer_Stop(void)
{	
	TIM_ITConfig(TIM3,TIM_IT_Update,DISABLE);
	TIM_Cmd(TIM3,DISABLE);
	TIM_SetCounter(TIM3,0);
}

//us����
//�˺�����usart.c�ļ��е�USART��ʼ�������б�����
void Modbus_Set_Timeout(uint32_t *_BaudRate)
{
	uint16_t us = 0;
	
//	us = 1000000 / _BaudRate * 10 * 7 / 2;
	us = 35000000 / (*_BaudRate);
	
	//�����г�������ʱ�����������������Σ�����ȥС�������Դ˴�reloadֵ����ȥ1.
	TIM_SetAutoreload(TIM3,us);
}

void TIM3_IRQHandler(void)
{
	uint16_t Len = 0;
	uint16_t Modbus_ERR_CODE_Send_Len = 5;
	
	if(TIM_GetITStatus(TIM3,TIM_IT_Update))
	{
		TIM_ClearITPendingBit(TIM3,TIM_IT_Update);
		//ֹͣ��ʱ��
		Modbus_Timer_Stop();
		
		//����ȡ���ĵ�ַд�뵽�Ĵ�����
//		Device_Address = Address_Get();
		
		
//		Device_Address = 1;
		RegBuffer[34] = Device_Address >> 8;
		RegBuffer[35] = Device_Address;
		
		if(Usart_Rev_counter == 8)
		{
			if(((Receive_Transmit_Buffer[1] == 3)||(Receive_Transmit_Buffer[1] == 4)||
					(Receive_Transmit_Buffer[1] == 5)||(Receive_Transmit_Buffer[1] == 1)||
					(Receive_Transmit_Buffer[1] == 2)||(Receive_Transmit_Buffer[1] == 6)))
					{
						Len = Modbus_Rtu(Receive_Transmit_Buffer,RegBuffer,DI_Status,Coil_Status,Device_Address);
						Usart_Send(Receive_Transmit_Buffer,Len);
					}
					else
					{
						//��֧�ֵĹ�����
						Packing_ErrCode(Receive_Transmit_Buffer,ERR_CODE_CMD,&Modbus_ERR_CODE_Send_Len);
						Usart_Send(Receive_Transmit_Buffer,5);
					}
		}
		else
		{
			//���ȴ����쳣��
			Packing_ErrCode(Receive_Transmit_Buffer,ERR_CODE_LEN,&Modbus_ERR_CODE_Send_Len);
			Usart_Send(Receive_Transmit_Buffer,5);
		}
			//�����ݴ������֮���������ֵ
		Usart_Rev_counter = 0;
	}

}



//PA9-TIM1-Base
//��ʱ��1��Ϊϵͳ��־��ʱ��
void Tim1_Init(void)
{
	NVIC_InitTypeDef	NVIC_InitStruct;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	
	//����TIM1��ʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1,ENABLE);

	//��ʱ��ʱ����ʼ��
	TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStruct.TIM_Period = 1000-1;
	TIM_TimeBaseInitStruct.TIM_Prescaler = 72-1;
	TIM_TimeBaseInitStruct.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM1,&TIM_TimeBaseInitStruct);
	
	NVIC_InitStruct.NVIC_IRQChannel = TIM1_UP_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
 NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 2;
 NVIC_InitStruct.NVIC_IRQChannelSubPriority = 2;
	NVIC_Init(&NVIC_InitStruct);
	
	TIM_ITConfig(TIM1,TIM_IT_Update,ENABLE);
	
 TIM_Cmd(TIM1, ENABLE);
}

void TIM1_UP_IRQHandler(void)
{
	static uint16_t TimesCounter_ms = 0;
	if(TIM_GetITStatus(TIM1,TIM_IT_Update))
	{
		TimesCounter_ms++;
		TIM_ClearITPendingBit(TIM1,TIM_IT_Update);
		if(TimesCounter_ms == 2000)
		{
			TimesCounter_ms = 0;
   OS_Flag.Temperature_Humidity_Flag = 1;
		}
	}

}



