#ifndef __ADC_H
#define __ADC_H
#include "stm32f10x.h"

extern uint16_t NH3_H2S_ADCRESULT[2];

void NH3_H2S_Adc_Init(void);

void Get_NH3_Value(void);
void Get_H2S_Value(void);

#endif



