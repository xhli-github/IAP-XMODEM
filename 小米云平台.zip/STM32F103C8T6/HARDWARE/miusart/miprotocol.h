#ifndef __MIPROTOCOL_H
#define __MIPROTOCOL_H
#include "stm32f10x.h"

void MIProtocol_Down_Process(char *MIProtocol_Buffer);



#endif

