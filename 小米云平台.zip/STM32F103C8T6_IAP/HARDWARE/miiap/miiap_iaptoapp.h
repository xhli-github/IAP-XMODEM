#ifndef __MIIAPIAPTOAPP_H
#define __MIIAPIAPTOAPP_H
#include "stm32f10x.h"


void IAP_JumpToApp(uint32_t APP_Address);


#endif


