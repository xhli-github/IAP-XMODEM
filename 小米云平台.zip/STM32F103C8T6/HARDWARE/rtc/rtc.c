#include "rtc.h"


void Rtc_Init(void)
{
	

}



