#include "modbus_timer.h"
#include "usart.h"
#include "gpio.h"
#include "flash.h"
#include "SysRest.h"
#include "delay.h"


//ע����д����ʱѡ�񲿷ֲ�����������������flash�д洢�������޼������ʵ����ݡ�
uint8_t DI_Status[DI_Status_Len] = {0};
uint8_t Coil_Status[Coil_status_Len] = {0};
uint8_t RegBuffer[RegBuffer_Len] = {0};
uint8_t Receive_Transmit_Buffer[Receive_Transmit_Buffer_Len] = {0};
uint16_t Device_Address = 0;


//ʵ��MODBUSRTUЭ���CRCУ��
static uint16_t CRC_16_MODBUS_RTU(uint8_t *CRC_MODBUS_Array,uint8_t CRC_MODBUS_Length)
{
	uint16_t CRC_MODBUS_Result = 0xffff;
	uint8_t i = 0;
	uint8_t j = 0;
	uint8_t CRC_MODBUS_Temp[2] = {0};
	
	for(i=0;i<CRC_MODBUS_Length;i++)
	{
		CRC_MODBUS_Result ^= CRC_MODBUS_Array[i];
		for(j=0;j<8;j++)
		{
			if(CRC_MODBUS_Result&0x01)
			{
				CRC_MODBUS_Result >>= 1;
				CRC_MODBUS_Result ^= 0xA001;
			}
			else
			{
				CRC_MODBUS_Result >>= 1;
			}
		}
	}
	CRC_MODBUS_Temp[0] = CRC_MODBUS_Result >> 8; //��8λ
	CRC_MODBUS_Temp[1] = CRC_MODBUS_Result;			 //��8λ
	
	CRC_MODBUS_Result = (CRC_MODBUS_Temp[1] << 8) + CRC_MODBUS_Temp[0];
	
	return CRC_MODBUS_Result;
}

uint16_t Modbus_Rtu(uint8_t *__Receive_Transmit_Buffer,uint8_t *__RegBuffer,uint8_t *__DI_Status,
										uint8_t *__Coil_Status,uint8_t Device_address)
{
	uint16_t Receive_Crc = 0;
	uint16_t Modbus_Send_Len = 0;
	
	//����豸��ַ��1����254 ���ҹ�����Ϊ1��2��3��4��5��6 ��ʼ��ַ��8λΪ0
	if(((__Receive_Transmit_Buffer[0] == Device_address)||(__Receive_Transmit_Buffer[0] == 254))&&
		((__Receive_Transmit_Buffer[1] == 3)||(__Receive_Transmit_Buffer[1] == 4)||
		(__Receive_Transmit_Buffer[1] == 5)||(__Receive_Transmit_Buffer[1] == 1)||
		(__Receive_Transmit_Buffer[1] == 2)||(__Receive_Transmit_Buffer[1] == 6)))
		{
			Receive_Crc = (__Receive_Transmit_Buffer[6]<<8) + __Receive_Transmit_Buffer[7];
			if (Receive_Crc == CRC_16_MODBUS_RTU(__Receive_Transmit_Buffer,6))
			{
				//������03 04Ϊ���Ĵ���
				if((__Receive_Transmit_Buffer[1] == 3)||(__Receive_Transmit_Buffer[1] == 4))
					{
						FunCode03_04(__Receive_Transmit_Buffer,__RegBuffer,&Modbus_Send_Len);
					}

				//д��Ȧ 01 05 00 00 FF 00 CL CH	Tx:01 05 00 01 FF 00 DD FA
				else if((__Receive_Transmit_Buffer[1] == 5)&&(__Receive_Transmit_Buffer[5] == 0))
				{
					FunCode05(__Receive_Transmit_Buffer,__Coil_Status,&Modbus_Send_Len);
				}
		
			//��Ȧ״̬������������01,TX 01 01 00 00 00 02 BD CB RX:01 01 01 01 90 48
				else if(__Receive_Transmit_Buffer[1] == 1)
				{
					FunCode01(__Receive_Transmit_Buffer,__Coil_Status,&Modbus_Send_Len);
				}
				
				else if(__Receive_Transmit_Buffer[1] == 2) 
				{
					FunCode02(__Receive_Transmit_Buffer,__DI_Status,&Modbus_Send_Len);
				}
				else if(__Receive_Transmit_Buffer[1] == 6)
				{
					FunCode06(__Receive_Transmit_Buffer,__RegBuffer,&Modbus_Send_Len);
				}
				else
				{
//					#ifdef Rs485_Auto
//						Rs485_EN();
//					#else
					GPIO_ResetBits(GPIOA, GPIO_Pin_8);
//					#endif
				}
		}
		else
			{
				//У��ʧ�ܴ������
				Packing_ErrCode(Receive_Transmit_Buffer,ERR_CODE_CRC,&Modbus_Send_Len);
			}
	}
	return Modbus_Send_Len;
}

//void Set_Relay(void)
//{

//	if((Coil_Status[0]&0x01) == 1)
//		{
//			Relay1_Set();
//		}
//	else if((Coil_Status[0]&0x01) == 0)
//		{
//			Relay1_Reset();
//		}
//	if((Coil_Status[1]&0x01) == 1)
//		{
//			Relay2_Set();
//		}
//	else if((Coil_Status[1]&0x01) == 0)
//		{
//			Relay2_Reset();
//		}
//	if((Coil_Status[2]&0x01) == 1)
//		{
//			Relay3_Set();
//		}
//	else if((Coil_Status[2]&0x01) == 0)
//		{
//			Relay3_Reset();
//		}
//	if((Coil_Status[3]&0x01) == 1)
//		{
//			Relay4_Set();
//		}
//	else if((Coil_Status[3]&0x01) == 0)
//		{
//			Relay4_Reset();
//		}
//}

//��ȡ����8bit��ʱ�������
void FunCode01(uint8_t *__Receive_Transmit_Buffer,uint8_t *__Coil_Status,uint16_t *Modbus_Send_Len)
{
	uint16_t i = 0;
	uint8_t  j = 0;
	uint8_t Lastest_Byte_i = 0;
	uint16_t CoilAddress = 0;
	uint8_t Coil_Number = 0;
	uint8_t Coil_Byte_Number = 0;
	uint8_t Coil_Status_Temp = 0;
	uint8_t Lastest_Byte_OFF = 0;
	uint16_t CRC_16_MODBUS_RTU_Result = 0;
	
	CoilAddress = (__Receive_Transmit_Buffer[2]<<8) + (__Receive_Transmit_Buffer[3]);
	Coil_Number = (__Receive_Transmit_Buffer[4]<<8) + (__Receive_Transmit_Buffer[5]);
	
	Coil_Byte_Number = (Coil_Number / 8);
	Lastest_Byte_OFF = (Coil_Number % 8);
	
	if(Coil_Number <= Coil_status_Len)
	{
		if((CoilAddress + Coil_Number) <= Coil_status_Len)
		{
			for(i=0;i<Coil_Byte_Number;i++)
			{	
				for(j=0;j<8;j++)
				{
					Coil_Status_Temp |= (__Coil_Status[CoilAddress + j + (8*i)] << j);
				}
				__Receive_Transmit_Buffer[3+i] = Coil_Status_Temp;
				Coil_Status_Temp = 0;
			}
			if(Lastest_Byte_OFF != 0)
			{
				for(Lastest_Byte_i = 0;Lastest_Byte_i<Lastest_Byte_OFF;Lastest_Byte_i++)
				{
					Coil_Status_Temp |= (__Coil_Status[(Coil_Number - Lastest_Byte_OFF) + CoilAddress + Lastest_Byte_i] << Lastest_Byte_i);
				}
				__Receive_Transmit_Buffer[Coil_Byte_Number+3] = Coil_Status_Temp;
				//������֮����Ҫ��ֵ��գ������Ӱ����һ�ζ�ȡ��
				Coil_Status_Temp = 0;
				Coil_Byte_Number++;
			}
			
			__Receive_Transmit_Buffer[2] = Coil_Byte_Number;
			
			CRC_16_MODBUS_RTU_Result = CRC_16_MODBUS_RTU(__Receive_Transmit_Buffer,__Receive_Transmit_Buffer[2]+3);
			__Receive_Transmit_Buffer[__Receive_Transmit_Buffer[2]+3] = CRC_16_MODBUS_RTU_Result >> 8;
			__Receive_Transmit_Buffer[__Receive_Transmit_Buffer[2]+4] = CRC_16_MODBUS_RTU_Result;

			*Modbus_Send_Len = __Receive_Transmit_Buffer[2]+5;
		}
		else
		{
			Packing_ErrCode(__Receive_Transmit_Buffer,ERR_CODE_REG_ADDR,Modbus_Send_Len);
		}
	}
	else
	{
		Packing_ErrCode(__Receive_Transmit_Buffer,ERR_CODE_VALUE,Modbus_Send_Len);
	}
}

void FunCode05(uint8_t *__Receive_Transmit_Buffer,uint8_t *__Coil_Status,uint16_t *Modbus_Send_Len)
{
	uint16_t Coil_Address = 0;
	Coil_Address = ((__Receive_Transmit_Buffer[2]<<8) + __Receive_Transmit_Buffer[3]);
	if((__Receive_Transmit_Buffer[5]==0x00) && ((__Receive_Transmit_Buffer[4] == 0x00) || (__Receive_Transmit_Buffer[4] == 0xFF)))
	{
		if(Coil_Address < Coil_status_Len)
		{
			if(__Receive_Transmit_Buffer[4] == 0xFF)//��
			{
				__Coil_Status[Coil_Address] = 1;
			}	
			else if(__Receive_Transmit_Buffer[4] == 0x00)//��
			{
				__Coil_Status[Coil_Address] = 0;
			}	
			*Modbus_Send_Len = 8;	
		}
		else
		{
			Packing_ErrCode(__Receive_Transmit_Buffer,ERR_CODE_REG_ADDR,Modbus_Send_Len);
		}
	}
	else
	{
		Packing_ErrCode(__Receive_Transmit_Buffer,ERR_CODE_VALUE,Modbus_Send_Len);
	}
}

void FunCode02(uint8_t *__Receive_Transmit_Buffer,uint8_t *__DI_Status,uint16_t *Modbus_Send_Len)
{
	uint16_t i = 0;
	uint8_t  j = 0;
	uint8_t Lastest_Byte_i = 0;
	uint16_t DIAddress = 0;
	uint8_t DI_Number = 0;
	uint8_t DI_Byte_Number = 0;
	uint8_t DI_Status_Temp = 0;
	uint8_t Lastest_Byte_OFF = 0;
	uint16_t CRC_16_MODBUS_RTU_Result = 0;
	
	DIAddress = (__Receive_Transmit_Buffer[2]<<8) + (__Receive_Transmit_Buffer[3]);
	DI_Number = (__Receive_Transmit_Buffer[4]<<8) + (__Receive_Transmit_Buffer[5]);
	
	DI_Byte_Number = (DI_Number / 8);
	Lastest_Byte_OFF = (DI_Number % 8);
	
	if(DI_Number <= DI_Status_Len)
	{
		if((DIAddress + DI_Number) <= DI_Status_Len)
		{
			for(i=0;i<DI_Byte_Number;i++)
			{	
				for(j=0;j<8;j++)
				{
					DI_Status_Temp |= (__DI_Status[DIAddress + j + (8*i)] << j);
				}
				__Receive_Transmit_Buffer[3+i] = DI_Status_Temp;
				DI_Status_Temp = 0;
			}
			if(Lastest_Byte_OFF != 0)
			{
				for(Lastest_Byte_i = 0;Lastest_Byte_i<Lastest_Byte_OFF;Lastest_Byte_i++)
				{
					DI_Status_Temp |= (__DI_Status[(DI_Number - Lastest_Byte_OFF) + DIAddress + Lastest_Byte_i] << Lastest_Byte_i);
				}
				__Receive_Transmit_Buffer[DI_Byte_Number+3] = DI_Status_Temp;
				//������֮����Ҫ��ֵ��գ������Ӱ����һ�ζ�ȡ��
				DI_Status_Temp = 0;
				DI_Byte_Number++;
			}
			
			__Receive_Transmit_Buffer[2] = DI_Byte_Number;
			
			CRC_16_MODBUS_RTU_Result = CRC_16_MODBUS_RTU(__Receive_Transmit_Buffer,__Receive_Transmit_Buffer[2]+3);
			__Receive_Transmit_Buffer[__Receive_Transmit_Buffer[2]+3] = CRC_16_MODBUS_RTU_Result >> 8;
			__Receive_Transmit_Buffer[__Receive_Transmit_Buffer[2]+4] = CRC_16_MODBUS_RTU_Result;

			*Modbus_Send_Len = __Receive_Transmit_Buffer[2]+5;
		}
		else
		{
			Packing_ErrCode(__Receive_Transmit_Buffer,ERR_CODE_REG_ADDR,Modbus_Send_Len);
		}
	}
	else
	{
		Packing_ErrCode(__Receive_Transmit_Buffer,ERR_CODE_VALUE,Modbus_Send_Len);
	}
}

void FunCode03_04(uint8_t *__Receive_Transmit_Buffer,uint8_t *__RegBuffer,uint16_t *Modbus_Send_Len)
{
	uint32_t Address_Offset = 0;
	uint16_t CRC_16_MODBUS_RTU_Result = 0;
	uint8_t n = 0;

	Address_Offset = ((__Receive_Transmit_Buffer[2] << 8) + __Receive_Transmit_Buffer[3]) * 2;
	
	__Receive_Transmit_Buffer[2] = (uint8_t)((__Receive_Transmit_Buffer[4] << 8) +__Receive_Transmit_Buffer[5])*2;
	
	if((__Receive_Transmit_Buffer[2] >= 1)&&(__Receive_Transmit_Buffer[2] <= RegBuffer_Len))
	{
		//�ж���ʼ��ַ+Ҫ��ȡ�������Ƿ�С��ϵͳ�мĴ������������
		if((Address_Offset + __Receive_Transmit_Buffer[2]) <= RegBuffer_Len)
		{
			for (n = 0;n < __Receive_Transmit_Buffer[2];n++)
			{
				__Receive_Transmit_Buffer[n+3] = __RegBuffer[n+Address_Offset];
			}
			//����CRCУ��λ
			CRC_16_MODBUS_RTU_Result = CRC_16_MODBUS_RTU(__Receive_Transmit_Buffer,__Receive_Transmit_Buffer[2]+3);
			__Receive_Transmit_Buffer[__Receive_Transmit_Buffer[2]+3] = CRC_16_MODBUS_RTU_Result >> 8;
			__Receive_Transmit_Buffer[__Receive_Transmit_Buffer[2]+4] = CRC_16_MODBUS_RTU_Result;
			
			*Modbus_Send_Len = __Receive_Transmit_Buffer[2]+5;	
		}
		else
		{
			Packing_ErrCode(__Receive_Transmit_Buffer,ERR_CODE_REG_ADDR,Modbus_Send_Len);
		}
	}
	else
	{
		Packing_ErrCode(__Receive_Transmit_Buffer,ERR_CODE_VALUE,Modbus_Send_Len);
	}
}					
						
void FunCode06(uint8_t *__Receive_Transmit_Buffer,uint8_t *__RegBuffer,uint16_t *Modbus_Send_Len)
{
	uint8_t n = 0;
	uint16_t Address_Offset = 0;
	uint16_t Reg_Value = 0;
	
	Address_Offset = ((__Receive_Transmit_Buffer[2] << 8) + __Receive_Transmit_Buffer[3]);
	Reg_Value = ((__Receive_Transmit_Buffer[4] << 8) + __Receive_Transmit_Buffer[5]);
	
	if(Reg_Value <= 0xFFFF)
	{

		switch(Address_Offset)
		{
		case 13:
			for(n = 0;n<2;n++)
			{
				__RegBuffer[26+n] = (__Receive_Transmit_Buffer[4+n]);
			}
	//								Flash_ReadDeviceData(DeviceAddressPage,Flash_Data);
			Flash_Data[0] = ((__RegBuffer[26] << 8)+ __RegBuffer[27]);
			if(Flash_WriteDeviceHalfWord(DeviceAddressPage,Flash_Data))
			{
				__RegBuffer[27] = (Flash_Data[0]);
				__RegBuffer[26] = (Flash_Data[0]>>8);
				*Modbus_Send_Len = 8;
			}
			else
			{
				__RegBuffer[27] = (Flash_Data[0]);
				__RegBuffer[26] = (Flash_Data[0]>>8);
				Packing_ErrCode(__Receive_Transmit_Buffer,ERR_CODE_WRITE,Modbus_Send_Len);
			}
		break;
		case 14:
		for(n = 0;n<2;n++)
			{
				__RegBuffer[28+n] = (__Receive_Transmit_Buffer[4+n]);
			}
		//								Flash_ReadDeviceData(DeviceAddressPage,Flash_Data);
			Flash_Data[1] = ((__RegBuffer[28] << 8)+ __RegBuffer[29]);
			if(Flash_WriteDeviceHalfWord(DeviceAddressPage,Flash_Data))
			{
				__RegBuffer[29] = (Flash_Data[1]);
				__RegBuffer[28] = (Flash_Data[1]>>8);
				*Modbus_Send_Len = 8;
			}
			else
			{
				__RegBuffer[29] = (Flash_Data[1]);
				__RegBuffer[28] = (Flash_Data[1]>>8);
				Packing_ErrCode(__Receive_Transmit_Buffer,ERR_CODE_WRITE,Modbus_Send_Len);
			}
		break;
		case 15:
		for(n = 0;n<2;n++)
			{
				__RegBuffer[30+n] = (__Receive_Transmit_Buffer[4+n]);
			}
		//								Flash_ReadDeviceData(DeviceAddressPage,Flash_Data);
			Flash_Data[2] = ((__RegBuffer[30] << 8)+ __RegBuffer[31]);
			if(Flash_WriteDeviceHalfWord(DeviceAddressPage,Flash_Data))
			{
				__RegBuffer[31] = (Flash_Data[2]);
				__RegBuffer[30] = (Flash_Data[2]>>8);
				*Modbus_Send_Len = 8;
			}
			else
			{
				__RegBuffer[31] = (Flash_Data[2]);
				__RegBuffer[30] = (Flash_Data[2]>>8);
				Packing_ErrCode(__Receive_Transmit_Buffer,ERR_CODE_WRITE,Modbus_Send_Len);
			}
		break;
		case 16:
		for(n = 0;n<2;n++)
			{
				__RegBuffer[32+n] = (__Receive_Transmit_Buffer[4+n]);
			}
		//								Flash_ReadDeviceData(DeviceAddressPage,Flash_Data);
			Flash_Data[3] = ((__RegBuffer[32] << 8)+ __RegBuffer[33]);
			if(Flash_WriteDeviceHalfWord(DeviceAddressPage,Flash_Data))
			{
				__RegBuffer[33] = (Flash_Data[3]);
				__RegBuffer[32] = (Flash_Data[3]>>8);
				*Modbus_Send_Len = 8;
			}
			else
			{
				__RegBuffer[33] = (Flash_Data[3]);
				__RegBuffer[32] = (Flash_Data[3]>>8);
				Packing_ErrCode(__Receive_Transmit_Buffer,ERR_CODE_WRITE,Modbus_Send_Len);
			}
		break;
		case 17:
			for(n = 0;n<2;n++)
			{
				__RegBuffer[34+n] = (__Receive_Transmit_Buffer[4+n]);
			}
//								Flash_ReadDeviceData(DeviceAddressPage,Flash_Data);
			Flash_Data[4] = ((__RegBuffer[34] << 8)+ __RegBuffer[35]);
			if(Flash_WriteDeviceHalfWord(DeviceAddressPage,Flash_Data))
			{
//				SysRest();
				Usart_Send(Receive_Transmit_Buffer,8);
				
				__disable_irq();
				NVIC_SystemReset();
				*Modbus_Send_Len = 8;
			}
			else
			{

				__RegBuffer[35] = (Flash_Data[4]);
				__RegBuffer[34] = (Flash_Data[4]>>8);
					Packing_ErrCode(__Receive_Transmit_Buffer,ERR_CODE_WRITE,Modbus_Send_Len);
			}
		break;
		case 18:
			for(n = 0;n<2;n++)
			{
				__RegBuffer[36+n] = (__Receive_Transmit_Buffer[4+n]);
			}
			
	//								Flash_ReadDeviceData(DeviceAddressPage,Flash_Data);
			Flash_Data[5] = ((__RegBuffer[36] << 8)+ __RegBuffer[37]);
			if(Flash_WriteDeviceHalfWord(DeviceAddressPage,Flash_Data))
			{
				Usart_Send(Receive_Transmit_Buffer,8);
				__disable_irq();
				NVIC_SystemReset();
				*Modbus_Send_Len = 8;
			}
			else
			{
				//�쳣��04
				__RegBuffer[37] = (Flash_Data[5]);
				__RegBuffer[36] = (Flash_Data[5]>>8);
				Packing_ErrCode(__Receive_Transmit_Buffer,ERR_CODE_WRITE,Modbus_Send_Len);
			}

		break;
		case 19:
			for(n = 0;n<2;n++)
			{
				__RegBuffer[38+n] = (__Receive_Transmit_Buffer[4+n]);
			}
			
	//								Flash_ReadDeviceData(DeviceAddressPage,Flash_Data);
			Flash_Data[6] = ((__RegBuffer[38] << 8)+ __RegBuffer[39]);
			if(Flash_WriteDeviceHalfWord(DeviceAddressPage,Flash_Data))
			{
				Usart_Send(Receive_Transmit_Buffer,8);
//				SysRest();
				__disable_irq();
				NVIC_SystemReset();
				*Modbus_Send_Len = 8;
			}
			else
			{
				__RegBuffer[39] = (Flash_Data[6]);
				__RegBuffer[38] = (Flash_Data[6]>>8);
				//�쳣��04
				Packing_ErrCode(__Receive_Transmit_Buffer,ERR_CODE_WRITE,Modbus_Send_Len);
			}
			break;
			default:
				//�쳣��02
				Packing_ErrCode(__Receive_Transmit_Buffer,ERR_CODE_REG_ADDR,Modbus_Send_Len);
			break;
		}
	}
	else
	{
	//�쳣��03
		Packing_ErrCode(__Receive_Transmit_Buffer,ERR_CODE_VALUE,Modbus_Send_Len);
	}
}

void Packing_ErrCode(uint8_t *__Receive_Transmit_Buffer,uint8_t ErrCode,uint16_t *Modbus_Send_Len)
{
	uint16_t CRC_16_MODBUS_RTU_Result = 0;
	
	__Receive_Transmit_Buffer[1] += 0x80;
	__Receive_Transmit_Buffer[2] = ErrCode;
	
	//����CRCУ��λ
	CRC_16_MODBUS_RTU_Result = CRC_16_MODBUS_RTU(__Receive_Transmit_Buffer,3);
	__Receive_Transmit_Buffer[3] = CRC_16_MODBUS_RTU_Result >> 8;
	__Receive_Transmit_Buffer[4] = CRC_16_MODBUS_RTU_Result;
	
	*Modbus_Send_Len = 5;
}

