#ifndef __USART_H
#define __USART_H

#include "stm32f10x.h"

void Rs485_Usart(void);
void Usart_Init(USART_TypeDef* USARTx,uint32_t USART_BaudRate);
void Usart_Send(uint8_t *Data,uint8_t Len);
void Usart_Send_Byte(USART_TypeDef* USARTx, uint16_t Data);
//void Usart_Send(USART_TypeDef* USARTx, uint8_t *Data ,uint32_t len);
//�жϷ�����
void USART1_IRQHandler(void);
void USART2_IRQHandler(void);
void USART3_IRQHandler(void);
void UART4_IRQHandler(void);
void UART5_IRQHandler(void);

#endif



