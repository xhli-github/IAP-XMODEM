#include "sysrest.h"
//#include "core_cm0.h"
//#include "core_cmFunc.h"

void SysRest(void)
{
	__disable_irq();
	NVIC_SystemReset();
}


