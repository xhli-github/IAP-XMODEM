#ifndef __TIMER_H
#define __TIMER_H
#include "stm32f10x.h"

typedef struct
{
 uint8_t Temperature_Humidity_Flag;
}OS_FLAG_t;
extern OS_FLAG_t OS_Flag;
void Timer_Init(void);
void Modbus_Timer_Start(void);
void Modbus_Timer_Stop(void);
void Modbus_Set_Timeout(uint32_t *_BaudRate);
void Tim1_Init(void);

#endif



