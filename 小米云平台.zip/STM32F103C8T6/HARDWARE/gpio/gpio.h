#ifndef __GPIO_H
#define __GPIO_H

#include "stm32f10x.h"



void Gpio_Init(GPIO_TypeDef* GPIOx,u16 Pin,GPIOMode_TypeDef Mode);
void Gpio_Set_Bit(GPIO_TypeDef* GPIOx,uint16_t GPIO_Pin);
void Gpio_Reset_Bit(GPIO_TypeDef* GPIOx,uint16_t GPIO_Pin);
u8 Gpio_Read_Bit(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);

#define ON 0
#define OFF 1
#define LED(a)\
							if(a == 0) Gpio_Reset_Bit(GPIOB,GPIO_Pin_5);\
							else Gpio_Set_Bit(GPIOB,GPIO_Pin_5);
							
							
//λ��������
#define Reg_Addr GPIOE_BASE + 0x0C
#define xhliPEout(n) (*((unsigned int *)(0x42000000 + (((Reg_Addr - 0x40000000) << 5)\
												+ (n << 2)))))



#endif
