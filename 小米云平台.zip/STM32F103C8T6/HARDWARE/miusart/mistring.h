#ifndef __MISTRING_H
#define __MISTRING_H
#include "stm32f10x.h"
#define Split_String_Buffer_Len 10

extern char *Split_String_Buffer[Split_String_Buffer_Len];

uint32_t MISplit_String(char *String,const char *delim);
uint32_t MIStringTouint32(char *String);
#endif


