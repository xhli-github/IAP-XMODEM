#ifndef __IWDG_H
#define __IWDG_H
#include "stm32f10x.h"

void Iwdg_Init(void);
void IWdg_Feed(void);


#endif









