#include "stm32f10x.h"
#include "delay.h"
#include "miusart.h"
#include "mistring.h"
#include "mitimer.h"
#include "miprotocol.h"
#include "mi_main.h"
#include "miiap_flash.h"

//char teststring[50] = "down set_properties 1 1 10\r";
//uint32_t test[10] = {0};
int main(void)
{
 //�����ж�������ƫ��
 NVIC_SetVectorTable(NVIC_VectTab_FLASH,VectorTableOffset);
 //�����ж�
 INTX_ENABLE();
	//�ж����ȼ�����
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
 Flash_ReadDeviceData(Flash_Data_Page,FLASH_Data_Buffer,FLASH_Data_Len);
	//��ʱ��ʼ��
	delay_init();
 MIUsart_Init();
 MIOSTimer_Init();
// Send_String("APP Running!\r\n");
 
 Send_String("mcu_version 0005\r\n");
 while(1)
 {
//  Send_String("This is a new APP!0001\r\n");
  MIProtocol_Down_Process(USART1_Receive_Buffer);
//  Send_String(Split_String_Buffer[0]);
//  delay_ms(1000);
//  Send_String(Split_String_Buffer[1]);
//  delay_ms(1000);
//  Send_String(Split_String_Buffer[2]);
//  delay_ms(1000);
//  test[0] = MIStringTouint32(Split_String_Buffer[2]);
//  delay_ms(1000);
//  Send_String(Split_String_Buffer[3]);
//  delay_ms(1000);
//  test[1] = MIStringTouint32(Split_String_Buffer[3]);
//  delay_ms(1000);
//  Send_String(Split_String_Buffer[4]);
//  delay_ms(1000);
//  test[2] = MIStringTouint32(Split_String_Buffer[4]);  
////		GPIO_SetBits(GPIOB, GPIO_Pin_5);
//// 	GPIO_ResetBits(GPIOE, GPIO_Pin_5);
////  delay_ms(500);
////		GPIO_SetBits(GPIOE, GPIO_Pin_5);
////		GPIO_ResetBits(GPIOB, GPIO_Pin_5);
//  delay_ms(1000);
 }
}


