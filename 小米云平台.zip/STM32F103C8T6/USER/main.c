#include "stm32f10x.h"
#include "delay.h"
#include "gpio.h"
#include "usart.h"
//#include "pwmdac.h"
#include "modbus_timer.h"
//#include "ht1621.h"
#include "flash.h"
//#include "iic.h"
//#include "ccp.h"
#include "adc.h"
#include "sgp30.h"
#include "tm1629a.h"
#include "hdc1080.h"
#include "iwdg.h"
#include "pmsa003.h"
#include "timer.h"
#include "ze08ch2o.h"

//ϵͳ��������
#define  HDC1080ENABLE  1
#define  PMSA003ENABLE  0
#define  SGP30ENABLE    0
#define  NH3_H2SENABLE  0
#define  CH2OENABLE     0

int main(void)
{
	//�ж����ȼ�����
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	//��ʱ��ʼ��
	delay_init();
#if HDC1080ENABLE
	Hdc1080_Init();
#endif
#if PMSA003ENABLE
 Pmsa003_Init();
#endif
#if SGP30ENABLE
	SGP30_Init();
#endif
//  usart��ʼ��
	Rs485_Usart();

// Usart_Init(USART2,9600);
	Iwdg_Init();
#if NH3_H2SENABLE
	NH3_H2S_Adc_Init();
#endif
#if CH2OENABLE
 CH2O_Init();
#endif
#if HDC1080ENABLE
 Get_HDC1080_Temperature();
 Get_HDC1080_Humidity();
 
 //ϵͳ�ϵ��Ȳɼ�һ����ʪ��
 OS_Flag.Temperature_Humidity_Flag = 1;
 Tim1_Init();
#endif
//	Usart_Init(USART3,115200);
//	Usart_Init(UART4,115200);
//	Usart_Init(UART5,115200);
//  	IIC_Init();
//		Tm1629_Init();
		while(1)
		{
			IWdg_Feed();
#if NH3_H2SENABLE
   Get_NH3_Value();
   Get_H2S_Value();
#endif
#if HDC1080ENABLE
   if(OS_Flag.Temperature_Humidity_Flag == 1)
   {
     OS_Flag.Temperature_Humidity_Flag = 0;
    	Get_HDC1080_Temperature();
     Get_HDC1080_Humidity();
   }
#endif
#if SGP30ENABLE
			SGP30_GetData();
#endif
		}

}


