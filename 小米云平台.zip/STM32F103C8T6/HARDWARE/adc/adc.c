#include "adc.h"
#include "dma.h"
#include "modbus_timer.h"

uint16_t NH3_H2S_ADCRESULT[2] = {0};

void NH3_H2S_Adc_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	ADC_InitTypeDef ADC_InitStruct;
	//����ADC��ϵͳʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1,ENABLE);
	//����GPIO��ʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	//����ADC��ʱ�ӷ�Ƶ������ܳ���14M.
	RCC_ADCCLKConfig(RCC_PCLK2_Div8);
	
	//��ʼ��GPIO
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_1;
	GPIO_Init(GPIOB,&GPIO_InitStruct);
	
	//��ʼ��ADC
	ADC_InitStruct.ADC_ContinuousConvMode = ENABLE;
	ADC_InitStruct.ADC_DataAlign = ADC_DataAlign_Right;
	ADC_InitStruct.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
	ADC_InitStruct.ADC_Mode = ADC_Mode_Independent;
	ADC_InitStruct.ADC_NbrOfChannel = 2;
	ADC_InitStruct.ADC_ScanConvMode = ENABLE;
	ADC_Init(ADC1,&ADC_InitStruct);
	
	//����ADCͨ��
	ADC_RegularChannelConfig(ADC1,ADC_Channel_8,1,ADC_SampleTime_239Cycles5);
	ADC_RegularChannelConfig(ADC1,ADC_Channel_9,2,ADC_SampleTime_239Cycles5);
//У׼ADC
	ADC_StartCalibration(ADC1);
	while(!ADC_GetCalibrationStatus(ADC1));
	
	//��ʼ��DMA
	ADC_DMA_Init(NH3_H2S_ADCRESULT);
	//����DMA����
	ADC_DMACmd(ADC1,ENABLE);
	//ʹ��ADC
	ADC_Cmd(ADC1,ENABLE);
	//����ADCת��
	ADC_SoftwareStartConvCmd(ADC1,ENABLE);

}

void Get_NH3_Value(void)
{
 uint16_t NH3_Value = 0;
 uint16_t NH3_Voltage = 0;
 int16_t NH3_Value_Temp = 0;
 if(ADC_EOC_FLAG == 1)
 {
  ADC_EOC_FLAG = 0;
  if(ADC_RESULT_AVE[0] >= (3.3 / 3.3 * 4095.0))
  {
   ADC_RESULT_AVE[0] = (3.3 / 3.3 * 4095.0);
  }
  NH3_Value_Temp = (int16_t)(((float)ADC_RESULT_AVE[0] / (3.3 / 3.3 * 4095.0)) * 1000.0 + (float)((RegBuffer[30] << 8) + RegBuffer[31]));
  if(NH3_Value_Temp >= 1000)
  {
   NH3_Value_Temp = 1000;
  }
  if(NH3_Value_Temp <= 0)
  {
   NH3_Value_Temp = 0;
  }
  NH3_Value = (uint16_t)NH3_Value_Temp;
  NH3_Voltage = (uint16_t)((float)ADC_RESULT_AVE[0] / 4096.0 * 3.3 * 1000.0 + 0.5);

  
 // if(NH3_H2S_ADCRESULT[0] >= (3.3 / 3.3 * 4095.0))
 // {
 //  NH3_H2S_ADCRESULT[0] = (3.3 / 3.3 * 4095.0);
 // }
 // NH3_Value = (uint16_t)(((float)NH3_H2S_ADCRESULT[0] / (3.3 / 3.3 * 4095.0)) * 1000.0 + (float)((RegBuffer[30] << 8) + RegBuffer[31]));
 // 
 // NH3_Voltage = (uint16_t)((float)NH3_H2S_ADCRESULT[0] / 4096.0 * 3.3 * 1000.0 + 0.5);
  RegBuffer[22] = (NH3_Voltage >> 8);
  RegBuffer[23] = NH3_Voltage;

  RegBuffer[4] = (NH3_Value >> 8);
  RegBuffer[5] = NH3_Value;
 }
}


void Get_H2S_Value(void)
{
 uint16_t H2S_Value = 0;
 uint16_t H2S_Voltage = 0;
 int16_t H2S_Value_Temp = 0;
 if(ADC_EOC_FLAG == 1)
 {
  ADC_EOC_FLAG = 0;
  if(ADC_RESULT_AVE[1] >= (3.3 / 3.3 * 4095.0))
  {
   ADC_RESULT_AVE[1] = (3.3 / 3.3 * 4095.0);
  }
  H2S_Value_Temp = (int16_t)(((float)ADC_RESULT_AVE[1] / (3.3 / 3.3 * 4095.0)) * 1000.0 + (float)((RegBuffer[32] << 8) + RegBuffer[33]));
  if(H2S_Value_Temp >= 1000)
  {
   H2S_Value_Temp = 1000;
  }
  else if(H2S_Value_Temp <= 0)
  {
   H2S_Value_Temp = 0;
  }
  H2S_Value = (uint16_t)H2S_Value_Temp;
  H2S_Voltage = (uint16_t)((float)ADC_RESULT_AVE[1] / 4096.0 * 3.3 * 1000.0 + 0.5);

  
 // if(NH3_H2S_ADCRESULT[1] >= (3.3 / 3.3 * 4095.0))
 // {
 //  NH3_H2S_ADCRESULT[1] = (3.3 / 3.3 * 4095.0);
 // }
 // H2S_Value = (uint16_t)(((float)NH3_H2S_ADCRESULT[1] / (3.3 / 3.3 * 4095.0)) * 1000.0 + (float)((RegBuffer[32] << 8) + RegBuffer[33]));

 // H2S_Voltage = (uint16_t)((float)NH3_H2S_ADCRESULT[1] / 4096.0 * 3.3 * 1000.0 + 0.5);
  RegBuffer[24] = (H2S_Voltage >> 8);
  RegBuffer[25] = H2S_Voltage;
  
  RegBuffer[6] = (H2S_Value >> 8);
  RegBuffer[7] = H2S_Value;
 }
}

