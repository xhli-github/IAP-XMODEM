#include "mixmodem.h"
#include "miiap_usart.h"
#include "delay.h"
#include "miiap_flash.h"
#include "string.h"




int XModemCRC(unsigned char *DataBuffer,int DataBufferLen)
{
 int crc = 0;  
 unsigned char i = 0;  
 crc = 0;  
 while(--DataBufferLen >= 0)
 {  
  crc = crc ^ (int) *DataBuffer++ << 8;  
  i = 8;  
  do  
  {  
   if (crc & 0x8000)  
       crc = crc << 1 ^ 0x1021;  
   else  
       crc = crc << 1;  
  } while (--i);  
 }
 
 crc &= 0xFFFF;
 
 return (crc);
}

uint8_t Xmodem_Protocol(unsigned char *DataBuffer)
{
 //��������У����ɵĴ�д��Flash�����ݡ�
 static unsigned char APPBINBuffer[APPBINBufferLen] = {0};
 static uint16_t APPBINBufferCounter = 0;
 static uint16_t APPPageCounter = 0;
 uint16_t BIN_Counter = 0;
 uint16_t CRC_Value = 0;
 uint16_t Timeout_Flag = 0;
 uint16_t TimeOut_Flag_2 = 0;
 uint8_t Data2Temp = 0;
 //Э�鿪ʼ
 
// while(((((Rec_FLAG_COUNTER_REG & 0x80000000) >> 31) == 0) && (Timeout_Flag < 10)))
 while(1)
 {
  memset(DataBuffer,0,USART1_Receive_Buffer_Max_Len);
  USART1_RECV_ENABLE();
  Send_String("C");
  while(((((Rec_FLAG_COUNTER_REG & 0x80000000) >> 31) == 0) && (TimeOut_Flag_2 < 300)))
  {
   TimeOut_Flag_2++;
   delay_ms(10);
  }
  TimeOut_Flag_2 = 0;
  if((((Rec_FLAG_COUNTER_REG & 0x80000000) >> 31) == 1))
  {
   Data2Temp = ~(DataBuffer[2]);
   CRC_Value = XModemCRC(&(DataBuffer[3]),128);
   if(((DataBuffer[131] == ((CRC_Value & 0xFF00)>> 8)) &&
      (DataBuffer[132] == (CRC_Value & 0x00FF)) && 
      (DataBuffer[0] == SOH) && ((DataBuffer[1]) == Data2Temp)))
   {
    Data2Temp = 0;
    break;
   }
   else
   {
    Data2Temp = 0;
    Rec_FLAG_COUNTER_REG = 0;
   }
  }
  Timeout_Flag++;
 }

// delay_ms(1000);
// while(((((Rec_FLAG_COUNTER_REG & 0x80000000) >> 31) == 0) && (Timeout_Flag < 10)))
// {
//  USART1_RECV_ENABLE();
//  delay_ms(1000);
//  delay_ms(1000);
//  delay_ms(1000);
//  Send_String("C");
//  delay_ms(1000);
//  while(((Rec_FLAG_COUNTER_REG & 0x80000000) >> 31) == 1);
//  delay_ms(1000);
//  Timeout_Flag++;
// }


// Timeout_Flag = 0;
// //��ʾ��Ϊ��ʱ����ѭ��
// if(((Rec_FLAG_COUNTER_REG & 0x80000000) >> 31) == 0)
// {
//  Send_String("Start overtime!\r\n");
//  return 0;
// }
 //���ֳ��򵽴˽���

 while(1)
 {
  if(((Rec_FLAG_COUNTER_REG & 0x80000000) >> 31) == 1)
  {
   Rec_FLAG_COUNTER_REG = 0;
   //��ʾ���յ������ַ�
   if(DataBuffer[0] == EOT)
   {
    IAP_WriteToFlash((APP_Page + APPPageCounter),APPBINBuffer,APPBINBufferCounter);
    APPPageCounter = 0;
    Send_Byte(ACK);
    memset(APPBINBuffer,0,APPBINBufferLen);
    memset(DataBuffer,0,USART1_Receive_Buffer_Max_Len);
//    USART1_RECV_ENABLE();
    return 1;
   }
   //У�鲻��Ҫ����ʼ�ֽں�У��ȣ��˴����޸ġ�
   Data2Temp = ~(DataBuffer[2]);
   CRC_Value = XModemCRC(&(DataBuffer[3]),128);
   while(((DataBuffer[131] != ((CRC_Value & 0xFF00)>> 8)) ||
      (DataBuffer[132] != (CRC_Value & 0x00FF)) || 
      (DataBuffer[0] != SOH) || ((DataBuffer[1]) != Data2Temp)) && 
      (Timeout_Flag < 10))
   {
    Rec_FLAG_COUNTER_REG = 0;
    TimeOut_Flag_2 = 0;
    memset(DataBuffer,0,USART1_Receive_Buffer_Max_Len);
    USART1_RECV_ENABLE();
    Send_Byte(NAK);
    while(((((Rec_FLAG_COUNTER_REG & 0x80000000) >> 31) == 0) && (TimeOut_Flag_2 < 100)))
    {
     TimeOut_Flag_2++;
     delay_ms(10);
    }
    //������½��յ�����������У��
    if(((Rec_FLAG_COUNTER_REG & 0x80000000) >> 31) == 1)
    {
     Data2Temp = ~(DataBuffer[2]);
     CRC_Value = XModemCRC(&(DataBuffer[3]),128);
    }
    TimeOut_Flag_2 = 0;
    Timeout_Flag++;
   }
   if(Timeout_Flag >= 10)
   {
    Send_String("CRC Error!\r\n");
    return 0;
   }
   Timeout_Flag = 0;
   //����У��ͨ��
   for(BIN_Counter = 0;BIN_Counter<128;BIN_Counter++)
   {
    APPBINBuffer[APPBINBufferCounter++] = DataBuffer[3+BIN_Counter];
 //   APPBINBuffer[((((DataBuffer[1] - 1) % 8) * 128) + Counter)] = DataBuffer[3+Counter]; 
   }
   //�ж�һҳ
 //  if(((((DataBuffer[1] - 1) % 8) + 1) * 128) == APPBINBufferLen)
   if(APPBINBufferCounter == APPBINBufferLen)
   {
    IAP_WriteToFlash((APP_Page + APPPageCounter),APPBINBuffer,APPBINBufferCounter);
    APPBINBufferCounter = 0;
    APPPageCounter++;
 //   IAP_WriteToFlash((APP_Page + ((DataBuffer[1] - 1) / 8)),APPBINBuffer,APPBINBufferLen);
    memset(APPBINBuffer,0,APPBINBufferLen);
   }
//    delay_ms(100);
//    USART1_RECV_ENABLE();
//    memset(USART1_Receive_Buffer,0,USART1_Receive_Buffer_Max_Len);
//    Send_Byte(ACK);
//    while(((((Rec_FLAG_COUNTER_REG & 0x80000000) >> 31) == 0) && (TimeOut_Flag_2 < 100)))
//    {
//     TimeOut_Flag_2++;
//     delay_ms(10);
//    }
//    if(((Rec_FLAG_COUNTER_REG & 0x80000000) >> 31) == 0)
//    {
//     USART1_RECV_ENABLE();
//     memset(USART1_Receive_Buffer,0,USART1_Receive_Buffer_Max_Len);
//     Send_Byte(ACK);
//    }
    
   //��մ��ڽ��ջ�����
   while(1)
   {
    memset(DataBuffer,0,USART1_Receive_Buffer_Max_Len);
    USART1_RECV_ENABLE();
    Send_Byte(ACK);
    while(((((Rec_FLAG_COUNTER_REG & 0x80000000) >> 31) == 0) && (TimeOut_Flag_2 < 100)))
    {
     TimeOut_Flag_2++;
     delay_ms(10);
    }
    TimeOut_Flag_2 = 0;
    //û�н��յ�����
    if(((Rec_FLAG_COUNTER_REG & 0x80000000) >> 31) == 0)
    {
     Timeout_Flag++;
     if(Timeout_Flag >= 10)
     {
      Timeout_Flag = 0;
      return 0;
     }
    }
    else if(((Rec_FLAG_COUNTER_REG & 0x80000000) >> 31) == 1)
    {
     Timeout_Flag = 0;
     break;
    }
   }
  }
 }
}



