#ifndef __MIMAIN_H
#define __MIMAIN_H
#include "stm32f10x.h"

#define VectorTableOffset     0x3C00


#endif


