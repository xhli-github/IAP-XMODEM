#include "pmsa003.h"
#include "usart.h"
#include "modbus_timer.h"

void Pmsa003_Init(void)
{
	Usart_Init(USART2,9600);
}


void USART2_IRQHandler(void)
{
	static uint8_t Counter = 0;
	static uint16_t PMSA003_value[32] = {0};
 uint8_t n = 0;
	static uint32_t PMSA003_SUM = 0;
	if(USART_GetITStatus(USART2,USART_IT_RXNE))
	{
		USART_ClearITPendingBit(USART2,USART_IT_RXNE);

		PMSA003_value[Counter++] = USART_ReceiveData(USART2);
  
		if((PMSA003_value[0] == 0X42)&&(PMSA003_value[1] == 0X4d)&&(PMSA003_value[2] == 0)
   &&(PMSA003_value[3] == 28)&&(Counter == 32))
		{
   Counter = 0;
   for(n=0;n<30;n++)
   {
    PMSA003_SUM += PMSA003_value[n];
   }
   if(((PMSA003_SUM & 0x0000ff00) >> 8) == PMSA003_value[30] && ((PMSA003_SUM & 0x000000FF)) == PMSA003_value[31])
   {
    //PM1.0
    RegBuffer[14] = PMSA003_value[10];
    RegBuffer[15] = PMSA003_value[11];
    //PM2.5
    RegBuffer[16] = PMSA003_value[12];
    RegBuffer[17] = PMSA003_value[13];
    //PM10
    RegBuffer[18] = PMSA003_value[14];
    RegBuffer[19] = PMSA003_value[15];
   }
   PMSA003_SUM = 0;
  }
  else if(((PMSA003_value[0] != 0X42)&&(Counter == 1))||
   ((PMSA003_value[0] == 0X42)&&(PMSA003_value[1] != 0X4d)&&(Counter == 2))||
  ((PMSA003_value[0] == 0X42)&&(PMSA003_value[1] == 0X4d)&&(PMSA003_value[2] != 0)&&(Counter == 3))||
  ((PMSA003_value[0] == 0X42)&&(PMSA003_value[1] == 0X4d)&&(PMSA003_value[2] == 0)&&(PMSA003_value[3] != 28)&&(Counter == 4)))
  {
   Counter = 0;
  }
  if(Counter == 32)
  {
   Counter = 0;
  }
 }
}



