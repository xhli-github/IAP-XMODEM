#ifndef __LED_H
#define __LED_H
#include "stm32f10x.h"

#define 				RCC_TM1629A_DIO_ENABLE			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE)
#define 				RCC_TM1629A_CLK_ENABLE			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE)
#define 				RCC_TM1629A_STB_ENABLE			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE)

#define 				TM1629A_DIO_Port						GPIOB
#define 				TM1629A_CLK_Port						GPIOB
#define 				TM1629A_STB_Port						GPIOB

#define 				TM1629A_DIO_Pin 						GPIO_Pin_12
#define 				TM1629A_CLK_Pin 						GPIO_Pin_13
#define 				TM1629A_STB_Pin 						GPIO_Pin_14

#define 				TM1629A_STB_H								GPIO_SetBits(TM1629A_STB_Port,TM1629A_STB_Pin);
#define 				TM1629A_STB_L								GPIO_ResetBits(TM1629A_STB_Port,TM1629A_STB_Pin);

#define 				TM1629A_CLK_H								GPIO_SetBits(TM1629A_CLK_Port,TM1629A_CLK_Pin);
#define 				TM1629A_CLK_L								GPIO_ResetBits(TM1629A_CLK_Port,TM1629A_CLK_Pin);

#define 				TM1629A_DIO_H								GPIO_SetBits(TM1629A_DIO_Port,TM1629A_DIO_Pin);
#define 				TM1629A_DIO_L								GPIO_ResetBits(TM1629A_DIO_Port,TM1629A_DIO_Pin);

void Tm1629_Init(void);
void TM1629_Write_Data(uint8_t Address,uint8_t *Data,uint8_t Len);
void Set_Display(uint32_t Data);
void Set_Temperature_Display(float Data);
void Set_Humidity_Display(float Data);
void Set_CO2_Display(uint32_t Data);
void Set_TVOC_Display(uint32_t Data);
void Set_CH20_Display(uint32_t Data);
void Set_PM1_0_Display(uint32_t Data);
void Set_PM2_5_Display(uint32_t Data);
void Set_PM10_Display(uint32_t Data);
#endif



