#ifndef __DMA_H
#define __DMA_H
#include "stm32f10x.h"

extern uint8_t ADC_EOC_FLAG;
extern uint16_t ADC_RESULT_AVE[2];
void ADC_DMA_Init(uint16_t *DMA_MemBaseAddr);
void USART2_DMA_Init(uint16_t *DMA_MemBaseAddr);


#endif



