#include "dma.h"
#include "adc.h"
uint32_t ADC_AVE_SUM[2] = {0};
uint16_t ADC_RESULT_AVE[2] = {0};
uint8_t ADC_EOC_FLAG = 0;
void ADC_DMA_Init(uint16_t *DMA_MemBaseAddr)
{
	DMA_InitTypeDef DMA_InitStruct;
 NVIC_InitTypeDef NVIC_InitStruct;
	//ʹ��DMAʱ��
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1,ENABLE);
	
	DMA_InitStruct.DMA_BufferSize = 2;
	DMA_InitStruct.DMA_DIR = DMA_DIR_PeripheralSRC;
	DMA_InitStruct.DMA_M2M = DMA_M2M_Disable;
	DMA_InitStruct.DMA_MemoryBaseAddr = (uint32_t)(DMA_MemBaseAddr);
	DMA_InitStruct.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
	DMA_InitStruct.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStruct.DMA_Mode = DMA_Mode_Circular;
	DMA_InitStruct.DMA_PeripheralBaseAddr = ((uint32_t)(&(ADC1->DR)));
	DMA_InitStruct.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
	DMA_InitStruct.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStruct.DMA_Priority = DMA_Priority_VeryHigh;
	DMA_Init(DMA1_Channel1,&DMA_InitStruct);
 
 NVIC_InitStruct.NVIC_IRQChannel = DMA1_Channel1_IRQn;
 NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
 NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 2;
 NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;
 NVIC_Init(&NVIC_InitStruct);
 
 DMA_ITConfig(DMA1_Channel1,DMA_IT_TC,ENABLE);
	//ʹ��DMA
	DMA_Cmd(DMA1_Channel1,ENABLE);
}

void DMA1_Channel1_IRQHandler(void)
{
 static uint32_t DMA_Counter = 0;
 if(DMA_GetITStatus(DMA_IT_TC))
 {
  DMA_ClearITPendingBit(DMA_IT_TC);
  if(ADC_EOC_FLAG == 0)
  {
   DMA_Counter++;
   ADC_AVE_SUM[0] = ADC_AVE_SUM[0] + NH3_H2S_ADCRESULT[0];
   ADC_AVE_SUM[1] = ADC_AVE_SUM[1] + NH3_H2S_ADCRESULT[1];
   if(DMA_Counter == 10)
   {
    DMA_Counter = 0;
    ADC_RESULT_AVE[0] = (uint16_t)((float)ADC_AVE_SUM[0] / 10.0 + 0.5);
    ADC_AVE_SUM[0] = 0;
    ADC_RESULT_AVE[1] = (uint16_t)((float)ADC_AVE_SUM[1] / 10.0 + 0.5);
    ADC_AVE_SUM[1] = 0;
    ADC_EOC_FLAG = 1;
   }
  }
 }
}

void USART2_DMA_Init(uint16_t *DMA_MemBaseAddr)
{
	DMA_InitTypeDef DMA_InitStruct;
	//ʹ��DMAʱ��
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1,ENABLE);
	
	DMA_InitStruct.DMA_BufferSize = 32;
	DMA_InitStruct.DMA_DIR = DMA_DIR_PeripheralSRC;
	DMA_InitStruct.DMA_M2M = DMA_M2M_Disable;
	DMA_InitStruct.DMA_MemoryBaseAddr = (uint32_t)(DMA_MemBaseAddr);
	DMA_InitStruct.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
	DMA_InitStruct.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStruct.DMA_Mode = DMA_Mode_Circular;
	DMA_InitStruct.DMA_PeripheralBaseAddr = ((uint32_t)(&(USART2->DR)));
	DMA_InitStruct.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
	DMA_InitStruct.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStruct.DMA_Priority = DMA_Priority_VeryHigh;
	DMA_Init(DMA1_Channel6,&DMA_InitStruct);
 
// DMA_ITConfig(DMA1_Channel6, uint32_t DMA_IT, FunctionalState NewState);
 
	//ʹ��DMA
	DMA_Cmd(DMA1_Channel6,ENABLE);
}


