#ifndef __MITIMER_H
#define __MITIMER_H
#include "stm32f10x.h"


void MIOSTimer_Init(void);



#endif


