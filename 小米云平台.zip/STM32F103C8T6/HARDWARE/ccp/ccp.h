#ifndef __CCP_H
#define __CCP_H
#include "stm32f10x.h"
void CCP_Init(uint16_t CCP_Period,uint16_t CCP_Prescaler);
uint16_t Get_CCP(void);
#endif





