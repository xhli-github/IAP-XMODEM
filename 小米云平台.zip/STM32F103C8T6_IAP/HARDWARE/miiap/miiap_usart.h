#ifndef __MIIAPUSART_H
#define __MIIAPUSART_H
#include "stm32f10x.h"

#define USART1_Receive_Buffer_Max_Len 140
extern unsigned char USART1_Receive_Buffer[USART1_Receive_Buffer_Max_Len];

extern uint32_t Rec_FLAG_COUNTER_REG;

void MIIAPUsart_Init(void);
void Send_String(char *String);
void USART1_RECV_ENABLE(void);
void USART1_RECV_DISABLE(void);
void Send_Hex(char *Data,unsigned int DataLen);
void Send_Byte(char Data);
#endif


