#include "ccp.h"

//δ������
void CCP_Init(uint16_t CCP_Period,uint16_t CCP_Prescaler)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	TIM_ICInitTypeDef TIM_ICInitStruct;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);  //ʹ��GPIOAʱ��
	
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0;  //PA0 ���֮ǰ����  
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD; //PA0 ����  
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_ResetBits(GPIOA,GPIO_Pin_0);						 //PA0 ����
	
	TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStruct.TIM_Period = CCP_Period;
	TIM_TimeBaseInitStruct.TIM_Prescaler = CCP_Prescaler;
	TIM_TimeBaseInitStruct.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM5,&TIM_TimeBaseInitStruct);
	
	TIM_ICInitStruct.TIM_Channel = TIM_Channel_1;
	//����IC�˲���
	TIM_ICInitStruct.TIM_ICFilter = 0;
	TIM_ICInitStruct.TIM_ICPolarity = TIM_ICPolarity_Rising;
	//����IC��Ƶ��
	TIM_ICInitStruct.TIM_ICPrescaler = TIM_ICPSC_DIV1;
	//ѡ��ӳ��ͨ��
	TIM_ICInitStruct.TIM_ICSelection = TIM_ICSelection_DirectTI;
	
	TIM_ICInit(TIM5,&TIM_ICInitStruct);
	
	TIM_Cmd(TIM5,ENABLE ); 	//ʹ�ܶ�ʱ��5
}

uint16_t Get_CCP(void)
{
	uint16_t CCR_Counter = 0;
	CCR_Counter = TIM_GetCapture1(TIM5);
	return CCR_Counter;
}

