#ifndef __MIOTA_H
#define __MIOTA_H
#include "stm32f10x.h"




#endif


