#ifndef __1621_H
#define __1621_H

#include "stm32f10x.h"
#include "gpio.h"


//HT1621ָ��
#define  BIAS     0x52             //0b1000 0101 0010  1/3duty 4com 
#define  SYSDIS   0X00             //0b1000 0000 0000  ����ϵͳ������LCDƫѹ������ 
#define  SYSEN    0X02             //0b1000 0000 0010 ��ϵͳ���� 
#define  LCDOFF   0X04             //0b1000 0000 0100  ��LCDƫѹ 
#define  LCDON    0X06             //0b1000 0000 0110  ��LCDƫѹ 
#define  XTAL     0x28             //0b1000 0010 1000 �ⲿ��ʱ�� 
#define  RC256    0X30             //0b1000 0011 0000  �ڲ�ʱ�� 
#define  WDTDIS1  0X0A            //0b1000 0000 1010  ��ֹ���Ź� 


//ģ��ӿڶ���
#define Ht1621_RCC_ENABLE 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE)
														 
#define Ht1621_CS_PORT (GPIOB)
#define Ht1621_CS_PIN  (GPIO_Pin_5)

#define Ht1621_WR_PORT (GPIOB)
#define Ht1621_WR_PIN  (GPIO_Pin_1)

#define Ht1621_DAT_PORT (GPIOB)
#define Ht1621_DAT_PIN  (GPIO_Pin_2)

#define Ht1621_GND_PORT (GPIOB)
#define Ht1621_GND_PIN  (GPIO_Pin_0)

#define Ht1621_VCC_PORT (GPIOB)
#define Ht1621_VCC_PIN  (GPIO_Pin_7)


//λ��������
//#define GPIOA_ODR_RegAddr 			GPIOA_BASE + 0x0C
//#define GPIOB_ODR_RegAddr 			GPIOB_BASE + 0x0C
//#define GPIOC_ODR_RegAddr 			GPIOC_BASE + 0x0C
//#define GPIOD_ODR_RegAddr 			GPIOD_BASE + 0x0C
//#define GPIOE_ODR_RegAddr 			GPIOE_BASE + 0x0C
//#define GPIOF_ODR_RegAddr 			GPIOF_BASE + 0x0C
//#define GPIOG_ODR_RegAddr 			GPIOG_BASE + 0x0C

//#define PAout(n) 								(0x42000000 + (((GPIOA_ODR_RegAddr - 0x40000000) << 5 ) + (n << 2)))
//#define PBout(n) 								(0x42000000 + (((GPIOB_ODR_RegAddr - 0x40000000) << 5 ) + (n << 2)))
//#define PCout(n) 								(0x42000000 + (((GPIOC_ODR_RegAddr - 0x40000000) << 5 ) + (n << 2)))
//#define PDout(n) 								(0x42000000 + (((GPIOD_ODR_RegAddr - 0x40000000) << 5 ) + (n << 2)))
//#define PEout(n) 								(0x42000000 + (((GPIOE_ODR_RegAddr - 0x40000000) << 5 ) + (n << 2)))
//#define PFout(n) 								(0x42000000 + (((GPIOF_ODR_RegAddr - 0x40000000) << 5 ) + (n << 2)))
//#define PGout(n) 								(0x42000000 + (((GPIOG_ODR_RegAddr - 0x40000000) << 5 ) + (n << 2)))



extern void Ht1621Wr_Data(unsigned char Data,unsigned char cnt) ;
extern void Ht1621WrCmd(unsigned char Cmd) ;
extern void Ht1621WrOneData(unsigned char Addr,unsigned char Data);
extern void Ht1621WrAllData(unsigned char Addr,unsigned char *p,unsigned char cnt);
extern void Ht1621_Init(void) ;
extern void Display(void) ;
extern void Display_lcd_dot(void) ;
extern void data_convertor(unsigned long adc_value) ;

//extern void Ht1621_CS_0();
void XHLITest(void);
void XHLITEST2(void);
#endif



