#include "flash.h"


uint16_t Flash_Data[Flash_Len] = {0};


uint8_t Flash_WriteDeviceHalfWord(uint32_t Page,uint16_t *Data)
{
	uint8_t i = 0;
	uint32_t Address_Temp = 0;
	uint16_t Flash_ReadData[Flash_Len] = {0};
	
	FLASH_Unlock();
	
	Address_Temp = (Page*1024+0x08000000);
	
	while(!(FLASH_ErasePage(Address_Temp)));
	
	for(i = 0;i<Flash_Len;i++)
	{
		FLASH_ProgramHalfWord(Address_Temp,Data[i]);
		Address_Temp  += 2;
	}	

	FLASH_Lock();
	
	Flash_ReadDeviceData(DeviceAddressPage,Flash_ReadData);
	if(Write_Read_Equal(Data,Flash_ReadData,Flash_Len))
	{
		return 1;
	}
	else
	{
		for(i = 0;i<Flash_Len;i++)
		{
				Data[i] = Flash_ReadData[i];
		}
		return 0;
	}
	
}


static uint8_t Write_Read_Equal(uint16_t *Array_Write,uint16_t *Array_Read,uint16_t Array_Len)
{
	uint16_t i = 0;
	for(i=0;i<Array_Len;i++)
	{
		if(Array_Write[i] != Array_Read[i])
		{
			return 0;
		}
	}
	return 1;
}


void Flash_ReadDeviceData(uint32_t Page,uint16_t *Flash_Data_Temp)
{
	uint8_t i = 0;
	uint32_t Address_Temp = 0;
	
	Address_Temp = (Page*1024+0x08000000);
	
	for(i=0;i<Flash_Len;i++)
	{
		Flash_Data_Temp[i] = (*((uint16_t *)(Address_Temp)));
		Address_Temp += 2;
	}
}

////��ȡFLASH�����ݲ���Ҫ����
//uint32_t Flash_Read_Word(uint32_t Address)
//{
//	uint32_t *Data = (uint32_t *)(Address);
//	return *Data;
//}

