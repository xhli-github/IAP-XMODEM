#ifndef __MIXMODEM_H
#define __MIXMODEM_H
#include "stm32f10x.h"
int XModemCRC(unsigned char *DataBuffer,int DataBufferLen);
#define  APP_Page  15

#define APPBINBufferLen 1024
#define SOH 0x01
#define STX 0x02
#define EOT 0x04
#define ACK 0X06
#define NAK 0x15
#define CAN 0x18
#define EOF 0x1A

uint8_t Xmodem_Protocol(unsigned char *DataBuffer);
#endif


