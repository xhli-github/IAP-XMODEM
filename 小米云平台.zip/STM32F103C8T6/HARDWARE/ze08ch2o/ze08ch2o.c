#include "ze08ch2o.h"
#include "usart.h"


//�жϴ�����USART.C
void CH2O_Init(void)
{
	Usart_Init(USART3,9600);
}



