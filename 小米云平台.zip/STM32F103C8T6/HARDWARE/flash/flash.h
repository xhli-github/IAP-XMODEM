#ifndef __FLASH_H
#define __FLASH_H
#include "stm32f10x.h"


uint8_t Flash_WriteDeviceHalfWord(uint32_t Page,uint16_t *Data);
void Flash_ReadDeviceData(uint32_t Page,uint16_t *Flash_Data_Temp);
static uint8_t Write_Read_Equal(uint16_t *Array_Write,uint16_t *Array_Read,uint16_t Array_Len);

#define 		Flash_Len 																				7
extern uint16_t Flash_Data[Flash_Len];

#define 		DeviceAddressPage    															20

#define 		Flash_Data_Upper1_Limer_Address				((uint32_t *)(0x08003C00))
#define 		Flash_Data_Lower1_Limer_Address				((uint32_t *)(0x08003C02))
#define 		Flash_Data_Upper2_Limer_Address				((uint32_t *)(0x08003C04))
#define 		Flash_Data_Lower2_Limer_Address				((uint32_t *)(0x08003C06))
#define 		Flash_Data_DeviceAddress_Address			((uint32_t *)(0x08003C08))
#define 		Flash_Data_BaudRate_Address						((uint32_t *)(0x08003C0A))
#define 		Flash_Data_Parity_Address							((uint32_t *)(0x08003C0C))

#define 		Flash_Data_Upper1_Limer								(*((uint32_t *)(0x08003C00)))
#define 		Flash_Data_Lower1_Limer								(*((uint32_t *)(0x08003C02)))
#define 		Flash_Data_Upper2_Limer								(*((uint32_t *)(0x08003C04)))
#define 		Flash_Data_Lower2_Limer								(*((uint32_t *)(0x08003C06)))
#define 		Flash_Data_DeviceAddress							(*((uint32_t *)(0x08003C08)))
#define 		Flash_Data_BaudRate										(*((uint32_t *)(0x08003C0A)))
#define 		Flash_Data_Parity											(*((uint32_t *)(0x08003C0C)))
#endif


