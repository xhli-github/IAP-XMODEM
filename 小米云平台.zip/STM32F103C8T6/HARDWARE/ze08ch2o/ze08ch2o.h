#ifndef __ZE08CH2O_H
#define __ZE08CH2O_H
#include "stm32f10x.h"
void CH2O_Init(void);



#endif

