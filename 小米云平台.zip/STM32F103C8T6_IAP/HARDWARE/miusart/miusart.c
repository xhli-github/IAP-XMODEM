#include "miusart.h"
#include "string.h"

char USART1_Receive_Buffer[USART1_Receive_Buffer_Max_Len] = {0};
uint32_t Rec_FLAG_COUNTER_REG = 0;

void MIUsart_Init(void)
{
 USART_InitTypeDef USART_InitStruct;
 NVIC_InitTypeDef NVIC_InitStruct;
 GPIO_InitTypeDef GPIO_InitStruct;
 DMA_InitTypeDef DMA_InitStruct;


 RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA, ENABLE);
 RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1,ENABLE);
 
 GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
 GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
 GPIO_InitStruct.GPIO_Pin = GPIO_Pin_9;//TX
 GPIO_Init(GPIOA,&GPIO_InitStruct);
 
 GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
 GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10;//RX
 GPIO_Init(GPIOA,&GPIO_InitStruct);

 USART_InitStruct.USART_BaudRate = 115200;
 USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
 USART_InitStruct.USART_Mode = USART_Mode_Rx|USART_Mode_Tx;
 USART_InitStruct.USART_Parity = USART_Parity_No;
 USART_InitStruct.USART_StopBits = USART_StopBits_1;
 USART_InitStruct.USART_WordLength = USART_WordLength_8b;
 USART_Init(USART1, &USART_InitStruct);
 
 NVIC_InitStruct.NVIC_IRQChannel = USART1_IRQn;
 NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
 NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0;
 NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;
 NVIC_Init(&NVIC_InitStruct);

 DMA_InitStruct.DMA_BufferSize = USART1_Receive_Buffer_Max_Len;
 DMA_InitStruct.DMA_DIR = DMA_DIR_PeripheralSRC;
 DMA_InitStruct.DMA_M2M = DMA_M2M_Disable;
 DMA_InitStruct.DMA_MemoryBaseAddr = (uint32_t)USART1_Receive_Buffer;
 DMA_InitStruct.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
 DMA_InitStruct.DMA_MemoryInc = DMA_MemoryInc_Enable;
 DMA_InitStruct.DMA_Mode = DMA_Mode_Normal;
 DMA_InitStruct.DMA_PeripheralBaseAddr = (uint32_t)(&(USART1->DR));
 DMA_InitStruct.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
 DMA_InitStruct.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
 DMA_InitStruct.DMA_Priority = DMA_Priority_VeryHigh;
 DMA_Init(DMA1_Channel5,&DMA_InitStruct);

 USART_ITConfig(USART1,USART_IT_IDLE,ENABLE);
 
 USART_DMACmd(USART1,USART_DMAReq_Rx,ENABLE);
 
 DMA_Cmd(DMA1_Channel5,DISABLE);
 USART_Cmd(USART1,ENABLE);
}

void USART1_RECV_ENABLE(void)
{
//  USART_ITConfig(USART1,USART_IT_IDLE,ENABLE);
  DMA_SetCurrDataCounter(DMA1_Channel5,USART1_Receive_Buffer_Max_Len);
  DMA_Cmd(DMA1_Channel5,ENABLE);
}

void USART1_RECV_DISABLE(void)
{
//  USART_ITConfig(USART1,USART_IT_IDLE,DISABLE);
  DMA_Cmd(DMA1_Channel5,DISABLE);
}

void USART1_IRQHandler(void)
{
 uint8_t Clear_IDLE_Flag = 0;
 if(USART_GetITStatus(USART1,USART_IT_IDLE))
 {
  //��������жϱ�־λ
  Clear_IDLE_Flag = USART1->SR;
  Clear_IDLE_Flag = USART1->DR;
  //Ϊ�˷�ֹ���������־���
  Clear_IDLE_Flag = Clear_IDLE_Flag;
  //�ر�DMA���������ü�����
  USART1_RECV_DISABLE();
//  DMA_Cmd(DMA1_Channel5,DISABLE);
  //���������λ��1
  Rec_FLAG_COUNTER_REG = 0x80000000;
  //�����յ����ݸ�����ֵ��Rec_FLAG_COUNTER_REG��
  Rec_FLAG_COUNTER_REG |= (USART1_Receive_Buffer_Max_Len - DMA_GetCurrDataCounter(DMA1_Channel5));

  //���ݴ������֮����մ��ڽ��ջ�����
//  memset(USART1_Receive_Buffer,0,USART1_Receive_Buffer_Max_Len);
  //��������DMA����ֵ���ҿ���DMA��
//  DMA_SetCurrDataCounter(DMA1_Channel5,USART1_Receive_Buffer_Max_Len);
//  DMA_Cmd(DMA1_Channel5,ENABLE);
 }
}


void Send_String(char *String)
{
 uint32_t Len = 0;
 uint32_t Usart1_Send_Counter = 0;
 Len = strlen(String);
 for(Usart1_Send_Counter = 0;Usart1_Send_Counter < Len;Usart1_Send_Counter++)
 {
  USART_ClearFlag(USART1,USART_FLAG_TC);
  USART_SendData(USART1,String[Usart1_Send_Counter]);
  while(!(USART_GetFlagStatus(USART1,USART_FLAG_TC)));
 }
}


